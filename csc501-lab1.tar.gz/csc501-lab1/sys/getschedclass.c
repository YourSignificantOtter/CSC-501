#include <kernel.h>
#include "lab1.h"

int getschedclass()
{
	return currScheduleType;
}
